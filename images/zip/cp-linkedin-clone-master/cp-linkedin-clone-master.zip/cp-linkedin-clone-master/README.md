# # Disney Plus Clone Readme

## <a href='https://linkedin-clone-b9f2a.web.app' target='_blank'>LIVE DEMO</a>

## Description
This is the ReactJS LinkedIn Clone, the perfect project to put on your portfolio by Clever Programmer.

## Build it today!

#### PREREQUISITES:
- Sign up for a Firebase account <a href='https://firebase.google.com'>HERE</a>
- Install Node JS in your computer <a href='https://nodejs.org/en/'>HERE</a> (Select the LTS option)
- Download all the images and videos <a href='https://drive.google.com/drive/folders/1czlG0rnLWJgNLhlU-tN6OVyB6xu1r5UU?usp=sharing'>HERE</a>
- Watch full tutorial <a href='https://youtu.be/xP3cxbDUtrc'>HERE</a>
