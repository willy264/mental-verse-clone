// 1. Basic Template Literal
// Create a variable named studentName and assign it a value of "Alex".
// Then, using template literals, construct a greeting string that says:
// "Welcome, Alex, to the JavaScript course!"
// and store this string in a variable named welcomeMessage.
// Finally, log welcomeMessage to the console.

const studentName = "Alex";
const welcomeMessage = `Welcome, ${studentName}, to the JavaScript course!`;
console.log(welcomeMessage); // Output: "Welcome, Alex, to the JavaScript course!"

// 2. Using Template Literals for Expressions
// Define two variables, price and taxRate, with values 100 and 0.2 respectively.
// Use template literals to create a string that displays the message:
// "The total price with tax is: $120"
// by calculating the total price including tax.
// Store this message in a variable named totalPriceMessage and log it to the console.

const price = 100;
const taxRate = 0.2;
const totalPriceMessage = `The total price with tax is: $${price * (1 + taxRate)}`;
console.log(totalPriceMessage); // Output: "The total price with tax is: $120"

// 3. Using a Function within Template Literals
// Write a function calculateArea that takes the width and height of a rectangle
// as parameters and returns its area.
// Then, create two variables, width and height, with values 10 and 20 respectively.
// Using a template literal, create a string that says:
// "The area of the rectangle is: 200 square units",
// by calling the calculateArea function within the template literal to calculate the area.
// Store this string in a variable named areaMessage and log it to the console.

// Define the calculateArea function
function calculateArea(width, height) {
    return width * height;
}
  
// Variables for width and height
const width = 10;
const height = 20;
  
// Create the areaMessage string using a template literal
const areaMessage = `The area of the rectangle is: ${calculateArea(width, height)} square units`;
  
// Log the areaMessage to the console
console.log(areaMessage); // Output: "The area of the rectangle is: 200 square units"

// 4. Using includes() and replace() String Methods
// Below is a string variable `quote` that contains the sentence: "The quick brown fox jumps over the lazy dog.".
// Check if the word "fox" is present in the quote.
// If it is, replace the word "fox" with "cat" and store the result in a new variable named updatedQuote.
// Then, log updatedQuote to the console.
// If the word "fox" is not found, simply log "Word not found" to the console.
  
const quote = "The quick brown fox jumps over the lazy dog.";

//Answer:
// Check if the word "fox" is present in the quote
if (quote.includes("fox")) {
    // Replace "fox" with "cat"
    const updatedQuote = quote.replace("fox", "cat");
    // Log the updated quote
    console.log(updatedQuote); // Output: "The quick brown cat jumps over the lazy dog."
} else {
    // Log if the word "fox" is not found
    console.log("Word not found");
}