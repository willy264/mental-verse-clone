// 1. Define a class named Book that represents a book in a library.
// The class should have a constructor that takes two parameters: title and author.
// It should also have a method named getDetails that logs the message:
// "Title: [title], Author: [author]",
// where [title] and [author] are replaced with the actual title and author of the book.

// Create an instance of the Book class with the title "The Great Gatsby" and the author "F.Scott Fitzgerald",
// then call the getDetails method on this instance.

// Create a second instance of the Book class with the title: "How to Win Friends and Influence People"
// and the author "Dale Carnegie",
// then call the getDetails method on this instance.