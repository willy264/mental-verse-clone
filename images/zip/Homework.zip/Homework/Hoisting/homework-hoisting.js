// 1. Predict what will be logged to the console when the following code is executed. Explain why.

console.log(myVar);
var myVar = 10;


// 2. What will happen when the following code is executed? Explain the outcome.

console.log(myLet);
let myLet = 20;

// 3. Given the following two pieces of code, predict the output of each
// and explain the differences in hoisting behavior.

// Code Snippet A:
funcDeclaration();

function funcDeclaration() {
  console.log("Function declaration is hoisted!");
}

// Code Snippet B:
funcExpression();

var funcExpression = function() {
  console.log("Function expression is not hoisted!");
};