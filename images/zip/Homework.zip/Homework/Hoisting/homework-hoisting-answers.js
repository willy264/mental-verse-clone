// 1. Predict what will be logged to the console when the following code is executed. Explain why.

console.log(myVar);
var myVar = 10;

// Answer:
// The code will log undefined to the console.
// This is because, due to hoisting, the declaration of myVar (i.e., var myVar;)
// is moved to the top of its scope. However, the initialization (myVar = 10;)
// stays in place and happens only when that line of code is reached, which is after the console.log.


// 2. What will happen when the following code is executed? Explain the outcome.

console.log(myLet);
let myLet = 20;

// Answer: The code will throw a ReferenceError: Cannot access 'myLet' before initialization.
// This occurs because variables declared with let (and const) are hoisted to the top of
// their block scope, but they are not initialized until the code defining them is executed.

// 3. Given the following two pieces of code, predict the output of each
// and explain the differences in hoisting behavior.

// Code Snippet A:
funcDeclaration();

function funcDeclaration() {
  console.log("Function declaration is hoisted!");
}

// Code Snippet B:
funcExpression();

var funcExpression = function() {
  console.log("Function expression is not hoisted!");
};

// Answer:
// Code Snippet A will output "Function declaration is hoisted!" to the console.
// This is because function declarations are fully hoisted, meaning both the declaration
// and the definition are moved to the top of their containing scope, allowing the function to be
// called before it's defined in the flow of the code.

// Code Snippet B will throw a TypeError: funcExpression is not a function.
// In this case, only the variable declaration (var funcExpression;) is hoisted to the top,
// and it is initialized with undefined. The function expression assigned to funcExpression is not hoisted.
// Therefore, trying to call funcExpression as a function before the assignment results in a TypeError,
// as funcExpression is undefined at the time of the call.