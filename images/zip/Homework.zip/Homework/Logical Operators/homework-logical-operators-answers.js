// 1. Given two variables: let a = 10 and let b = 15, using the AND operator
// check if both numbers are greater than 10 and assign the value to the "c" variable.
// What should the value of c be after the comparison is made?

let a = 10;
let b = 15;

// Answer:
let c = a > 10 && b > 10; // This will equal false because "a" is not greater than 10.

// 2. What should the output of this be?
console.log(true && true && true);

// Answer: true

// 3. Given two variables: let d = 13 and let e = 20, create a condition 
// using the OR operator that checks if at least one of the two variables equals 13 and
// assign the value to the "f" variable.
let d = 13;
let e = 20;

// Answer:
let f = d === 13 || e === 13;

// 4. What would the output of this be?
console.log(false || false || true || false);

// Answer: true

// 5. Create a variable named "isLoggedIn", set it's value to true, and then negate
// the value using the NOT operator.

// Answer:
let isLoggedIn = true;
isLoggedIn = !isLoggedIn;

// 6. What would the output of this be?
let name = "John";
console.log(name ?? "No Name Provided");

// Answer: John