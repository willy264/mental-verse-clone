// 1. Using the concept of class inheritance, define two classes:
// Vehicle as the parent class and Car as the child class that extends Vehicle.
// The Vehicle class should have a constructor that takes two parameters: 
// make and model, and initializes them.
// It should also have a method named getDetails that logs "This vehicle is a [make] [model].".

// The Car class should override the getDetails method to
// additionally include the type of vehicle in the message.
// For example, if the Car's make is "Toyota" and model is "Corolla",
// calling getDetails on a Car instance should log "This vehicle is a Toyota Corolla, and it is a car.".

// Create an instance of the Car class with the make "Toyota" and model "Corolla", 
// then call the getDetails method on this instance to demonstrate the overridden method.