// 1. Given an array of fruits: ["apple", "banana", "cherry"],
// use a for...of loop to log each fruit to the console.

const fruits = ["apple", "banana", "cherry"];

// Answer:
for (const fruit of fruits) {
    console.log(fruit); // Outputs each fruit: apple, banana, cherry
}

// 2. Create an array of numbers: const numbers = [1, 2, 3, 4, 5];.
// Use a for...of loop to calculate the sum of the numbers in the array.
// Print the sum to the console.

const numbers = [1, 2, 3, 4, 5];
// Answer:
let sum = 0;
for (const number of numbers) {
    sum += number;
}
console.log(sum); // Outputs: 15

// 3. Given the `book` object defined below, use a for...in loop to print each key and its value.

const book = {title: "1984", author: "George Orwell", year: 1949};

//Answer:
for (const key in book) {
    console.log(`${key}: ${book[key]}`);
}

// 4. Use the forEach() method on the array const elements = ["Hydrogen", "Helium", "Lithium"];
// to log each element along with its index in the format "[index]: [element]."

const elements = ["Hydrogen", "Helium", "Lithium"];

// Answer:
elements.forEach((element, index) => {
    console.log(`${index}: ${element}`);
});

// 5. Given an array of numbers const nums = [1, 2, 3, 4];
// use the forEach() method to double each number in the array. Print the modified array to the console.

const nums = [1, 2, 3, 4];

// Answer:
nums.forEach((num, index, arr) => arr[index] = num * 2);
console.log(nums); // Outputs: [2, 4, 6, 8]