// 1. Compare two numbers, 10 and 20, using the > operator and set the
// result to a variable.

// Answer:
let compare = 10 > 20;

// 2. Given two variables, let a = 15, and let b = 10, write a condition
// that checks if "a" is greater than or equal to "b". Output the result
// using console.log

let a = 15;
let b = 10;

// Answer:
console.log(a >= b);

// 3. What should the value of the "question3Result" variable be?

let question3Result = 5 == '5';

// Answer: true

// 4. What should the value of the "question4Result" variable be?

let question4Result = 5 === '5';

// Answer: false

// 5. What should the value of the "question5Result" variable be?

let x = 10;
let y = 15;
let question5Result = x != y;

// Answer: true