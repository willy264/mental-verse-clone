// Dice roll

// Using a 6 sided die -
// You're going to pick a number, 1 through 6 with each number simulating a side of a die.
// Once you pick a number you will simulate "rolling" the dice 3 times in an attempt
// to roll the number you picked.

// Each time the dice is rolled, output how many times you've rolled the dice
// and the number rolled.

// If the number you roll is greater than the number you picked then output:
// "The dice rolled higher than the number you picked!".

// If the number you roll is less than the number you picked then output:
// "The dice rolled lower than the number you picked!".

// If the number you roll equals the number you picked stop the program and output:
// "The dice rolled the number you picked!".

// If you roll the dice 3 times without landing on your number, stop the program and output:
// "You've ran out of tries to roll the dice"

let userInput = process.argv[2];

let numberPicked = Number(userInput);

//NaN = Not a Number

if (numberPicked < 1 || numberPicked > 6 || isNaN(numberPicked)) {
    console.log("You entered: " + userInput + ". You can only enter a number value between 1 through 6");
    process.exit();
} else {
    console.log("The number you picked is: " + numberPicked);
}

let numberOfRolls = 0;
let hasMatch = false;

const maxNumberOfRolls = 3;

do {

    // roll the dice
    numberOfRolls++;
    console.log("Current roll = " + numberOfRolls);

    // Simulate a dice "roll"
    // generate a random number from 1 - 6;

    // Built-in helper tools
    // Math.random(); // >= 0 & < 1 ---- 0 - 0.9999999
    const diceRoll = Math.floor(Math.random() * 6) + 1;
    console.log("The dice rolled a: " + diceRoll);

    if (diceRoll > numberPicked) {
        console.log("The dice rolled higher than the number you picked!");
    } else if (diceRoll < numberPicked) {
        console.log("The dice rolled lower than the number you picked!");
    } else { //if (diceRoll === numberPicked) {
        console.log("The dice rolled the number you picked!");
        hasMatch = true;
        break;
    }

} while (numberOfRolls < maxNumberOfRolls);

if (numberOfRolls >= maxNumberOfRolls && hasMatch === false) {
    console.log("You've ran out of tries to roll the dice");
}
