// 1. Create a variable named myNumber, and assign it a value of 8

// Answer:
let myNumber = 8;

// 2. Using the myNumber variable, add a value of 10 to it

// Answer:
myNumber = myNumber + 10;

// 3. What would the value of the "totalValue" variable be?
let number1 = 100;
let number2 = 250;
let totalValue =  number1 - number2;

// Answer: -150

// 4. Create a variable named x, assign it a value of 5, and multiply it by the value 
// of the "myNumber" variable created from question 1.

// Answer:
let x = 5;
x = x * myNumber;

// 5. Create two variables, divide those two variables by each other, and set the division
// value to a new variable.

// Answer:
let a = 200;
let b = 2;
let c = a / b;

// 6. Using the compound assignment operator, add 5 to the "myNumber" variable
// created from question 1.

// Answer:
myNumber += 5;

// 7. Using the compound assignment operator, subtract 7 from the "myNumber" variable
// created from question 1.

// Answer:
myNumber -= 7;

// 8. What would the value of the "question7Value" variable be?
myNumber = 7;
let question7Value = myNumber**3;

// Answer: 343

// 9. What would the value of the "question8Value" variable be?
myNumber = 15;
let question8Value = myNumber % 4;

// Answer: 3

// 10. Create a variable with a value of 10, and on the next line add 1 to it using the ++ operator.

// Answer:
let d = 10;
d++;

// 11. Create a variable with a value of 0, and on the next line subtract 1 from it using the -- operator.

// Answer:
let e = 0;
d--;