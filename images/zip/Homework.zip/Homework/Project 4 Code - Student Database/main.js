import { Class } from './Class.js';
import { Student } from './Student.js';
import readline from 'readline';

// Develop a program that enables users to input student grades 
// for multiple classes, using a scale ranging
// from 0 to 100 for each class grade.
// All the data should be stored in an organized data structure, 
// enabling users to easily retrieve a report card and the GPA 
// for each student.




const studentMap = new Map();

const config = {
    input: process.stdin,
    output: process.stdout,
}

const rl = readline.createInterface(config);

function addStudentPrompt() {
    const question = 'Enter a students name and grade for: Math, English, Science & History: ';
    rl.question(question, (userInput) => {
        //Jeff 100 73 83 100
        const inputArr = userInput.split(" ");
        const name = inputArr[0];
        const mathGrade = inputArr[1];
        const englishGrade = inputArr[2];
        const scienceGrade = inputArr[3];
        const historyGrade = inputArr[4];

        if (inputArr.length < 5
            || isNaN(mathGrade)
            || isNaN(englishGrade)
            || isNaN(scienceGrade)
            || isNaN(historyGrade)) {
                console.log("Invalid student data entered");
                addStudentPrompt();
        } else {
            const classes = [
                new Class("Math", mathGrade),
                new Class("English", englishGrade),
                new Class("Science", scienceGrade),
                new Class("History", historyGrade),
            ];

            const student = new Student(name, classes);
            studentMap.set(name, student);
            console.log('Added', name);
            promptUser();
        }

    });
}

function hasStudent(studentName, callback) {
    if (studentMap.has(studentName)) {
        const student = studentMap.get(studentName);
        callback(student);
    } else {
        console.log("No student found for", studentName);
    }

    promptUser();
}

function displayStudents() {
    // Jeff, Kevin, Todd, Tim
    const names = [];
    for (const [key] of studentMap) {
        names.push(key);
    }
    console.log(names.join(', '));
}

function promptUser() {
    rl.question('Enter a command (Type `cmd` to see all commands): ', (userInput) => {
        const args = userInput.split(" ");
        switch(args[0]) {
            case 'exit': {
                rl.close();
                return;
            }
            case 'add-student': {
                addStudentPrompt();
                break;
            }
            case 'report-card': {
                hasStudent(args[1], (student) => {
                    student.generateReportCard();
                });
                break;
            }

            case 'gpa': {
                //gpa Jeff
                hasStudent(args[1], (student) => {
                    student.generateGpa();
                });
                break;
            }
            case 'students': {
                displayStudents();
                promptUser();
                break;
            }
            case 'cmd': {
                console.log('exit |', 'exits the program');
                console.log('add-student |', 'adds a student and grades for each subject');
                console.log('report-card <student name> |', 'shows report card for student');
                console.log('gpa <student name> |', 'show gpa for student');
                console.log('students |', 'displays all students');
                promptUser();
                break;
            }
            default: {
                console.log("Invalid command.");
                promptUser();
            }
        }
        //add-student
        //report-card
        //gpa
        //exit
    });
}

promptUser();


// Math, English, Science, History
const classes = [
    new Class("Math", 100),
    new Class("English", 87),
    new Class("Science", 63),
    new Class("History", 92),
];

const john = new Student("John", classes);

const classes2 = [
    new Class("Math", 86),
    new Class("English", 91),
    new Class("Science", 73),
    new Class("History", 82),
];

const tom = new Student("Tom", classes2);

const classes3 = [
    new Class("Math", 85),
    new Class("English", 99),
    new Class("Science", 92),
    new Class("History", 99),
];

const alice = new Student("Alice", classes3);

studentMap.set("John", john);
studentMap.set("Tom", tom);
studentMap.set("Alice", alice);

// john.generateReportCard();
// john.generateGpa();