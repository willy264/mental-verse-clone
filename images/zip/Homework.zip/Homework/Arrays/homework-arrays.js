// 1. Add two values: "banana" and "apple" to the "fruits" array provided.
let fruits = ["orange", "pear"];


// 2. Using the .includes() helper method, check if the array "names" includes
// the name "John". Output the result to the console.
let names = ["Joe", "John", "Jason", "Jerry"];


// 3. Create an array with 5 values, and using a for loop
// iterate over each item in the array and output it to the console.


// 4. Using the "nums" array provided, count how many even numbers are in the array
// and output the count to the console. hint: use the modulus operator
let nums = [1, 7, 22, 5, 6, 8, 10, 1, 1, 3, 56];
let totalEvenNumbers = 0; // initialize count


// 5. Bonus Challenge Problem: Using a for loop, find the maximum number in the "numbers" array
// and output that value.
let numbers = [-500, -210, -67, -2222, -43, -123];

