// 1. Add two values: "banana" and "apple" to the "fruits" array provided.

let fruits = ["orange", "pear"];
fruits.push("banana");
fruits.push("apple");


// 2. Using the .includes() helper method, check if the "names" array includes
// the name "John". Output the result to the console.

let names = ["Joe", "John", "Jason", "Jerry"];
console.log(names.includes("John"));


// 3. Create an array with 5 values, and using a for loop
// iterate over each item in the array and output it to the console.

let array = ["kenny", 1, 5, "hello", false];

for (let i = 0; i < array.length; i++) {
   console.log(array[i]);
}


// 4. Using the "nums" array provided, count how many even numbers are in the array
// and output the count to the console. hint: use the modulus operator

let nums = [1, 7, 22, 5, 6, 8, 10, 1, 1, 3, 56];
let totalEvenNumbers = 0; // initialize count

for (let i = 0; i < nums.length; i++) {
   let num = nums[i];
   if (num % 2 === 0) {
       totalEvenNumbers += 1;
   }
}

console.log(totalEvenNumbers);


// 5. Bonus Challenge Problem: Using a for loop, find the maximum number in the "numbers" array
// and output that value.

let numbers = [-500, -210, -67, -2222, -43, -123];
let max = numbers[0];
for (let i = 1; i < numbers.length; i++) {
   if (numbers[i] > max) {
       max = numbers[i];
   }
}

console.log(max);

