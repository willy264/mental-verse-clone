// 1. How do you create an object in JavaScript that represents
// a book with properties for title, author, and yearPublished?
// Write the code to create such an object and name it book.

const book = {
    title: "The Great Gatsby",
    author: "F. Scott Fitzgerald",
    yearPublished: 1925
};

// 2. Given an object `user` (defined below), write the code to access 
// the email property of the user object using both dot notation and bracket notation.

const user = {
    username: "tech_guru",
    email: "tech@example.com",
    signUpYear: 2020
};

// 3. If you have an object `car` (defined below),
// How would you update the year property of the car object to 2021?

const car = {
    make: "Toyota",
    model: "Camry",
    year: 2019
};

// 4. With the person object (defined below), write a method inside 
// this object named updateAge that takes a new age as a parameter
// and updates the age property of the person object.
// Also, include a call to this method that updates the age to 35.

const person = {
    firstName: "John",
    lastName: "Doe",
    age: 30,
    greet: function() {
        console.log(`Hello, my name is ${this.firstName} ${this.lastName}.`);
    }
};

// 5. Consider the following student object (defined below) which contains nested objects.
// How would you access the science score of Emily from the student object?
// Write the code for accessing this nested property.

const student = {
    name: "Emily",
    details: {
        grade: 11,
        section: "A",
         scores: {
            math: 95,
            science: 88
        }
    }
};