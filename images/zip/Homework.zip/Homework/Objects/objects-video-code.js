// Objects

// Allow you to gather and organize multiple pieces of data under a single variable.

let firstName = "Kenny";
let lastName = "Gunderman";
let age = 28;
let email = "kenny@email.com";

let sister = {
   firstName: "Jenny",
   age: 22,
};

let brother = {
   firstName: "Josh",
   age: 34,
};

let person = {
   firstName: "Kenny",
   lastName: "Gunderman",
   age: 28,
   email: "kenny@email.com",
   '1year': 2025,
   // methods
   sayHello: function(name) {
      console.log("Hello, " + name);
   },
   fullName: function() {
      console.log(this.firstName + " " + this.lastName);
   },
   incrementAge: function(number) {
      this.age += number;
   },
   // object nesting
   siblings: [sister, brother]
};

// dot notation
// person.firstName;

// console.log(person.firstName);

// bracket notation

let key = 'firstName';

// console.log(person['1year']);
// person.sayHello("Dan");

// person.age += 1;

// person.fullName();

person.incrementAge(10);
console.log(person.siblings[1].firstName);


