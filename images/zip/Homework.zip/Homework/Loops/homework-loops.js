// 1. Write a while loop that counts up from 0 to 5.
// Log the count in each loop iteration with console.log

// 2. Write a while loop that logs numbers from 3 to 8, but stops if the number is 5.

// 3. Use a for loop to print numbers from 1 to 13 but skips numbers 7 and 10.

// 4. Using a do-while loop, run 20 loop iterations and log all the odd iterations.