// 1. Write a while loop that counts up from 0 to 5.
// Log the count in each loop iteration with console.log

// Answer:
let counter = 0;
while (counter < 5) {
    counter++;
    console.log(counter);
}

// 2. Write a while loop that logs numbers from 3 to 8, but stops if the number is 5.

// Answer:
let num = 3;
while (num <= 8) {
    if (num === 5) {
        break;
    }
    console.log(num);
    num++;
}

// 3. Use a for loop to print numbers from 1 to 13 but skips numbers 7 and 10.

// Answer:
for (let i = 1; i <= 13; i++) {
    if (i === 7 || i === 10) {
        continue;
    }
    console.log(i);
}

// 4. Using a do-while loop, run 20 loop iterations and log all the odd iterations.

// Answer:
let i = 1;
do {
    if (i % 2 === 1) {
        console.log(i); // Log the iteration number if it's odd
    }
    i++;
} while (i <= 20);