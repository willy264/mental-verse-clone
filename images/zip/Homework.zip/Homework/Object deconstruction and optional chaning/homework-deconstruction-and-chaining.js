// 1. Object Deconstruction
// Given an object representing a rectangle with properties length and width,
// use object destructuring to extract these properties into two variables.
// Then, calculate the area of the rectangle and log it to the console.

const rectangle = {
    length: 10,
    width: 5
};

// 2. Optional Chaining
// Consider an object `student` (defined below)
// that contains nested objects representing the student's contact information.
// Safely access the student's email address using optional chaining and log it to the console.
// If the email address is not available, the output should be undefined.

const student = {
    name: 'Jane Doe',
    contact: {
        email: 'jane.doe@example.com'
    }
};