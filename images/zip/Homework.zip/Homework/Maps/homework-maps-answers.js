// 1. Create an empty Map named colorsMap.
// Using the .set method, add three key-value pairs to the map:
// the key "red" with the value #FF0000, the key "green" with the value #00FF00,
// and the key "blue" with the value #0000FF.
// After adding these pairs, use console.log to output the map object, and to display the size of the map.

const colorsMap = new Map();
colorsMap.set("red", "#FF0000")
colorsMap.set("green", "#00FF00")
colorsMap.set("blue", "#0000FF");
console.log(colorsMap); // Outputs the map object
console.log(colorsMap.size); // Output: 3

// 2. Given a Map named studentGrades that maps student names to their grades,
// add two entries: "Alice" with a grade of 90 and "Bob" with a grade of 85.
// Then, write a line of code that retrieves and logs the grade for "Alice".

const studentGrades = new Map();
studentGrades.set("Alice", 90)
studentGrades.set("Bob", 85);
console.log(studentGrades.get("Alice")); // Output: 90

// 3. Using the studentGrades map, check if a student named "Bob" exists,
// and if a student named "John" exists.

console.log(studentGrades.has("Bob")); // Output: true
console.log(studentGrades.has("John")); // Output: false

// 4. Using the colorsMap map from problem 1, delete the "red" entry
// and log the updated map object and it's size.

colorsMap.delete("red");
console.log(colorsMap);
console.log(colorsMap.size);