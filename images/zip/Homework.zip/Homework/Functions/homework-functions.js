// 1. Write a function named multiply that takes three parameters and returns their product.
// Then, call this function with three numbers of your choice and display the result using console.log.

// 2. Create two functions that calculate the square of a number: one using function declaration
// and the other using function expression. Name them squareDecl and squareExpr, respectively.
// After defining both, call them with the same number and use console.log to output the results.
// Compare the outputs to ensure they are the same.

// 3. Rewrite the squareExpr function from the previous problem using arrow function syntax 
// and name it squareArrow. Then, call squareArrow with a number and display the result using console.log.

// 4. Write a function named logMessage that takes a string message as a parameter
// and prints it to the console inside the function body. Do not use a return statement in this function.
// After calling logMessage with a string, also attempt to print the return value of logMessage
// using console.log to observe what is returned by a function without a return statement.

// 5. Create a function named isEven that takes a number as a parameter and 
// returns true if the number is even and false if the number is odd.
// Use the modulus (%) operator to help determine if a number is even or not.
// Test your function with both an even and an odd number, and print the results using console.log.