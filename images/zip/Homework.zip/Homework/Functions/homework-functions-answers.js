// 1. Write a function named multiply that takes three parameters and returns their product.
// Then, call this function with three numbers of your choice and display the result using console.log.

function multiply(a, b, c) {
    return a * b * c;
}
  
// Call the function and display the result
console.log(multiply(4, 5, 1)); // Outputs: 20

// 2. Create two functions that calculate the square of a number: one using function declaration
// and the other using function expression. Name them squareDecl and squareExpr, respectively.
// After defining both, call them with the same number and use console.log to output the results.
// Compare the outputs to ensure they are the same.

// Function Declaration
function squareDecl(number) {
    return number * number;
}
  
// Function Expression
const squareExpr = function(number) {
    return number * number;
};
  
// Call both functions and compare outputs
console.log(squareDecl(6)); // Outputs: 36
console.log(squareExpr(6)); // Outputs: 36

// 3. Rewrite the squareExpr function from the previous problem using arrow function syntax 
// and name it squareArrow. Then, call squareArrow with a number and display the result using console.log.

// Arrow Function
const squareArrow = (number) => number * number;

// Call the function and display the result
console.log(squareArrow(7)); // Outputs: 49

// 4. Write a function named logMessage that takes a string message as a parameter
// and prints it to the console inside the function body. Do not use a return statement in this function.
// After calling logMessage with a string, also attempt to print the return value of logMessage
// using console.log to observe what is returned by a function without a return statement.

// Define the function
function logMessage(message) {
    console.log(message);
}
  
// Call the function with a string
logMessage("Hello, World!"); // Outputs: Hello, World!
  
// Attempt to print the return value of logMessage
console.log(logMessage("Hello again!")); // Outputs: Hello again! and then undefined

// 5. Create a function named isEven that takes a number as a parameter and 
// returns true if the number is even and false if the number is odd.
// Use the modulus (%) operator to help determine if a number is even or not.
// Test your function with both an even and an odd number, and print the results using console.log.

// Define the function
function isEven(number) {
    return number % 2 === 0;
}
  
// Test the function with an even number
console.log(isEven(4)); // Outputs: true
  
// Test the function with an odd number
console.log(isEven(5)); // Outputs: false