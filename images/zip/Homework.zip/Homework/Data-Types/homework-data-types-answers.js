// 1. Create a variable and assign it a value with the data-type of string

// Answer:
let userName = 'John';

// 2. Create a variable and assign it a value with the data-type of number

// Answer:
let userAge = 44;

// 3. Create a variable and assign it a value with the data-type of boolean

// Answer:
let isTheSkyBlue = true;

// 4. Create a variable and assign it a value with the data-type of bigint

// Answer:
let googol = BigInt(10000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000);

// 5. Create a variable with an undefined value

// Answer:
let undefVar;

// 6. Create a variable and assign it a value with the data-type of null

// Answer:
let nullVar = null;

// 7. Create a variable, assign it to any value, and on the next line null it out

// Answer:
let firstName = "Joe";
firstName = null;

// 8. What are these 6 data-types: string, number, boolean, bigInt, undefined and null known as?
// a) non-primitive data-types
// b) oldschool data-types
// c) primitive data-types
// d) computer data-types

// Answer: c

// 9. What keyword can I use to determine the data-type of a variable?
// a) if
// b) while
// c) typeof
// d) var

// Answer: c

// 10. What type of programming is JavaScript?
// a) dynamically-typed
// b) statically-typed
// c) objectively-typed

// Answer: a