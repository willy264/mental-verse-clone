// 1. Create a variable and assign it a value with the data-type of string

// 2. Create a variable and assign it a value with the data-type of number

// 3. Create a variable and assign it a value with the data-type of boolean

// 4. Create a variable and assign it a value with the data-type of bigint

// 5. Create a variable with an undefined value

// 6. Create a variable and assign it a value with the data-type of null

// 7. Create a variable, assign it to any value, and on the next line null it out

// 8. What are these 6 data-types: string, number, boolean, bigInt, undefined and null known as?
// a) non-primitive data-types
// b) oldschool data-types
// c) primitive data-types
// d) computer data-types

// 9. What keyword can I use to determine the data-type of a variable?
// a) if
// b) while
// c) typeof
// d) var


// 10. What type of programming is JavaScript?
// a) dynamically-typed
// b) statically-typed
// c) objectively-typed