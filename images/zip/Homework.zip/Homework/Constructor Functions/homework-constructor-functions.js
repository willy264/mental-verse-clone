// Write a constructor function named `Vehicle` that can be used to
// create objects representing different types of vehicles.
// Each vehicle should have properties for make, model, and year,
// and a method getDetails that logs a string containing these details in the format:
// "This is a [year] [make] [model]."
// For example, if a vehicle has a make of "Toyota", a model of "Corolla", and a year of 2020,
// calling getDetails on this vehicle should log "This is a 2020 Toyota Corolla."

// After defining the constructor function, create two instances of Vehicle:
// one representing a 2020 Toyota Corolla and another representing a 2018 Ford Mustang.
// Call the getDetails method on each instance to demonstrate their functionality.