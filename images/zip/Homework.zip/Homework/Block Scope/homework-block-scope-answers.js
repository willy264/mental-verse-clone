// 1. Where does this program error? Explain why.

// Answer:

if (true) { // <- outer scope
    let outerVar = "outer";
    {
        let innerVar = "inner"; // <- inner scope
        console.log(outerVar);
        console.log(innerVar);
    }
    
    console.log(outerVar);
    console.log(innerVar); // The program errors here
    // This is because innerVar is contained within the "inner" scope and the "outer" scope
    // doesn't have access to variables within the inner scope.
  }