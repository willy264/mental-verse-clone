// 1. Where does this program error? Explain why.

if (true) {
    let outerVar = "outer";
    {
        let innerVar = "inner";
        console.log(outerVar);
        console.log(innerVar);
    }
    
    console.log(outerVar);
    console.log(innerVar);
  }