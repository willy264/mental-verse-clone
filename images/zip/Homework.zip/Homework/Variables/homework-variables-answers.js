// 1. Create a let variable named: city, and assign it a value of "New York"

// Answer:
let city = "New York";

// 2. Create a constant named: state, and assign it a value of "California"

// Answer:
let state = "California";

// 3. Create a let variable with the camel case naming notation. Assign it whatever value you want.

// Answer:
let brandOfCar = "Tesla";

// 4. Create a let variable named: weather, and assign it a value of "sunny". 
// On the next line of the program reassign the variable's value to "raining".

// Answer:
let weather = "sunny";
weather = "raining";

// 5. Why are variables called "variables"
// a) because the value of a variable is likely to change throughout the program
// b) because they never change throughout the program

// Answer: a