// 1. Concatenate the following three variables together with a space (" ")
// and output the combination with conosole.log.

let firstName = "Bobby";
let middleInitial = "J";
let lastName = "Turtle";

// Answer:
console.log(firstName + " " + middleInitial + " " + lastName);