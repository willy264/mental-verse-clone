// 1. Basic Callback Function
// Write a function named processUserInput that 
// takes two parameters: a user's name and a callback function.
// The processUserInput function should call the callback function and pass 
// the user's name to it. Your callback function should print a 
// greeting to the console using the name.
// Call your processUserInput function to demonstrate this functionality.

// 2. Mathematical Operations as Callbacks
// Create a function called `calculate` that takes three parameters:
// two numbers and a callback function to perform an operation on these numbers.
// Implement callbacks for addition, subtraction, and multiplication.
// Then, call `calculate` with different operations and print the results.

// 3. Using Callbacks for Asynchronous Simulation
// Imagine a scenario where you're downloading a file,
// and you want to process the file once it's downloaded.
// Write a function downloadFile that simulates downloading
// by printing "Downloading file..." and then calls a callback function
// after a delay (use setTimeout for the delay).
// The callback should print "File processed".
// Demonstrate how you would call downloadFile with the appropriate callback.

// 4. Bonus Challenge Problem - Function That Returns a Function
// Write a simple function named `wrapWithCallback` that takes 
// a single callback function as its parameter.
// This function should return a new function that, when executed, 
// calls the provided callback function with a single argument it receives.