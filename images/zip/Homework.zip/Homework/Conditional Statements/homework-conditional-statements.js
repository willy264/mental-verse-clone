// 1 . Write an if statement that logs "Welcome" to the console if the variable 
// isUserLoggedIn is true.

let isUserLoggedIn = true;

// 2. Create an if-else statement that checks if a number is positive or negative and
// logs "Positive" if the number is positive and "Negative" if the number is negative.

// 3. Write a program with an if-else-if statement that logs: 
// "Child", "Teenager", "Adult" based on the age variable.

let age = 15;

// 4. Create a program that:
// Checks if userAge is greater than 18.
// If userAge is greater than 18, log "Is older than 18".
// If userAge is greater than 18, and hasPermission is true, log "Access granted".
// If userAge is not greater than 18, log "Too young".
// hint: use a nested if statement

let userAge = 20;
let hasPermission = true;

// 5. Use a switch statement to log the day of the week based on a dayNumber.
// 1 = Monday, 2 = Tuesday, etc.

let dayNumber = 3;