// 1 . Write an if statement that logs "Welcome" to the console if the variable 
// isUserLoggedIn is true.

let isUserLoggedIn = true;

// Answer:
if (isUserLoggedIn) {
    console.log("Welcome");
}

// 2. Create an if-else statement that checks if a number is positive or negative and
// logs "Positive" if the number is positive and "Negative" if the number is negative.


// Answer:
let number = -5;
if (number > 0) {
    console.log("Positive");
} else {
    console.log("Negative");
}

// 3. Write a program with an if-else-if statement that logs: 
// "Child", "Teenager", "Adult" based on the age variable.

let age = 15;

// Answer:
if (age < 13) {
    console.log("Child");
} else if (age < 18) {
    console.log("Teenager");
} else {
    console.log("Adult");
}

// 4. Create a program that:
// Checks if userAge is greater than 18.
// If userAge is greater than 18, log "Is older than 18".
// If userAge is greater than 18, and hasPermission is true, log "Access granted".
// If userAge is not greater than 18, log "Too young".
// hint: use a nested if statement

let userAge = 20;
let hasPermission = true;


// Answer:
if (userAge > 18) {
    console.log("Is older than 18");
    if (hasPermission) {
        console.log("Access granted");
    }
} else {
    console.log("Too young");
}

// 5. Use a switch statement to log the day of the week based on a dayNumber.
// 1 = Monday, 2 = Tuesday, etc.

let dayNumber = 3;

// Answer:
switch (dayNumber) {
    case 1: 
        console.log("Monday");
        break;
    case 2: 
        console.log("Tuesday");
        break;
    case 3: 
        console.log("Wednesday");
        break;
    case 4:
        console.log("Thursday");
        break;
    case 5:
        console.log("Friday");
        break;
    case 6:
        console.log("Saturday");
        break;
    case 7:
        console.log("Sunday");
        break;
    default: 
        console.log("Invalid day");
}