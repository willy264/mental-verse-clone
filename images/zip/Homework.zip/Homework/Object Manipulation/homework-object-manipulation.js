// 1. Deleting Object Properties
// You have an object `car` (defined below) that represents a car with properties make, model, and year.
// Use the `delete` keyword to remove the year property from the car object.
// Then, log the car object to the console to verify that the year property has been removed.

let car = {
    make: 'Toyota',
    model: 'Camry',
    year: 2020
};

// 2. Adding New Properties to an Object
// Given an object `student` (defined below) that represents a student with a name and grade,
// add a new property school with the value "Lincoln High School" to the student object.
// Then, log the student object to the console to verify that the new property has been added.

let student = {
    name: 'Alice',
    grade: 'A'
};

// 3. Spread Operator
// Use the spread operator to create a copy of the person object (defined below).
// Name the copy personCopy and then add a new property email with the value
// "john.doe@example.com" to personCopy.
// Log both person and personCopy to the console to demonstrate that person has not been modified.

let person = {
    name: 'John',
    age: 30
};
  
// 4. Merging Objects
// Given have two objects, `basicInfo` and `contactInfo` (defined below),
// Use the spread operator to merge basicInfo and contactInfo into a new object named completeInfo.
// Log completeInfo to the console to verify the result.

let basicInfo = {
    name: 'Jane',
    age: 25
};
  
let contactInfo = {
    email: 'jane.doe@example.com',
    phone: '555-1234'
};

// 5. Merging Arrays with the Spread Operator
// Given two arrays of numbers: `array1` and `array2` (defined below),
// merge these two arrays into a single array that combines their element and maintains their order.
// Use the spread operator to accomplish this task.
// After merging the arrays, log the resulting array to the console to verify your solution.

const array1 = [1, 2, 3];
const array2 = [4, 5, 6];